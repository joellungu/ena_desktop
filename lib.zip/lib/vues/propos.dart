import 'package:flutter/material.dart';

class Propos extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        width: 400,
        alignment: Alignment.center,
        child: SingleChildScrollView(
          child: Text(
            """MOKPONGBO LUNGU JOEL   0815381693\n
Dolore ipsum aliqua exercitation aliquip nostrud. Qui anim exercitation Lorem deserunt enim minim velit reprehenderit. Minim anim dolore Lorem veniam aliqua id commodo eiusmod quis. Proident voluptate laboris Lorem pariatur exercitation id est duis dolore ea laborum. Elit cupidatat eiusmod laborum mollit laboris mollit cillum deserunt. Eiusmod mollit incididunt occaecat occaecat do incididunt esse proident velit sunt do non. Excepteur ipsum id ipsum cillum proident ad proident.""",
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }
}
