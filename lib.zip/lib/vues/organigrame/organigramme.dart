import 'package:flutter/material.dart';

class Organigrame extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
