class Utils {
  static Uri lienUrl = Uri.http(
    'example.org',
    '/api',
  );
}
