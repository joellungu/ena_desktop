class Utils {
  static String url = "http://localhost:9090";
  static Uri lienUrl = Uri.http(
    'example.org',
    '/api',
  );
  /*
  get:
  http:
  url_launcher: ^6.1.5
  path_provider: ^2.0.11
  get_storage: ^2.0.3
  file_picker: ^4.6.1
  data_table_2: ^2.3.5
  pdf: ^3.8.1
  printing: ^5.9.1
  */
}
